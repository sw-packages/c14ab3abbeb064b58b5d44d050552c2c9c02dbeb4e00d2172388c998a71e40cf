/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */
#include <aws/common/environment.h>
#include <aws/common/file.h>
#include <aws/common/logging.h>
#include <aws/common/string.h>

int aws_file_path_read_from_offset_direct_io(
    const struct aws_string *file_path,
    uint64_t offset,
    size_t max_read_length,
    struct aws_byte_buf *output_buf,
    size_t *out_actual_read) {
    (void)file_path;
    (void)offset;
    (void)max_read_length;
    (void)output_buf;
    (void)out_actual_read;
    /* TODO: Support it cross different platforms. */
    AWS_LOGF_ERROR(AWS_LS_COMMON_GENERAL, "Direct file IO is not supported yet on platforms other than linux.");
    return aws_raise_error(AWS_ERROR_UNSUPPORTED_OPERATION);
}

int aws_file_path_write_to_offset_direct_io(
    const struct aws_string *file_path,
    uint64_t offset,
    struct aws_byte_cursor data) {
    (void)file_path;
    (void)offset;
    (void)data;
    AWS_LOGF_ERROR(AWS_LS_COMMON_GENERAL, "Direct file IO is not supported yet on platforms other than linux.");
    return aws_raise_error(AWS_ERROR_UNSUPPORTED_OPERATION);
}

int aws_file_open_direct_io_for_write(const struct aws_string *file_path, int *out_fd) {
    (void)file_path;
    (void)out_fd;
    AWS_LOGF_ERROR(AWS_LS_COMMON_GENERAL, "Direct file IO is not supported yet on platforms other than linux.");
    return aws_raise_error(AWS_ERROR_UNSUPPORTED_OPERATION);
}

int aws_file_write_to_offset_direct_io(int fd, uint64_t offset, struct aws_byte_cursor data) {
    (void)fd;
    (void)offset;
    (void)data;
    AWS_LOGF_ERROR(AWS_LS_COMMON_GENERAL, "Direct file IO is not supported yet on platforms other than linux.");
    return aws_raise_error(AWS_ERROR_UNSUPPORTED_OPERATION);
}

bool aws_file_direct_io_is_supported(void) {
    return false;
}
